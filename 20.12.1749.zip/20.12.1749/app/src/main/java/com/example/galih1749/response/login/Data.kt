package com.example.galih1749.response.login

data class Data(
    val admin: Admin,
    val token:String
)
