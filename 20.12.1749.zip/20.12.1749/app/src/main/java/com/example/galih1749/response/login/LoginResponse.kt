package com.example.galih1749.response.login

data class LoginResponse(
    val success:Boolean,
    val message:String,
    val data: Data
)
